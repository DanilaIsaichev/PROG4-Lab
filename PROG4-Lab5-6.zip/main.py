import sqlite3

try:
    conn = sqlite3.connect('zhukov.db')
except sqlite3.DatabaseError:
    print("Не удалось подключиться к базе данных")

curs = conn.cursor()

def READ(table, attribute = None, value = None):
  if (attribute == None and value == None):
    try:
      data = curs.execute('SELECT * from %s' % table)
    except sqlite3.OperationalError:
      print("Ошибка при выполнении операции считывания")
    else:
      for i in data:
        print(i)
  else:
    try:
      if type(value) is int:
        data = curs.execute("SELECT * from %s WHERE %s = %i" % (table, attribute, value))
      elif type(value) is float:
        data = curs.execute("SELECT * from %s WHERE %s = %f" % (table, attribute, value))
      else:
        data = curs.execute("SELECT * from %s WHERE %s = '%s'" % (table, attribute, value))
    except sqlite3.OperationalError:
        print("Ошибка при выполнении операции считывания")
    else:
      for i in data:
        print(i)

def ADD(table, attributes, values):
  str_attr = "("
  str_val = "("
  for i in range(len(attributes)):
    if i < len(attributes) - 1:
      if type(values[i]) is int:
        str_val += ("%i, " % values[i])
      elif type(values[i]) is float:
        str_val += ("%f, " % values[i])
      else:
        str_val += ("'%s', " % values[i])

      if type(attributes[i]) is str:
        str_attr += ("%s, " % attributes[i])
      else:
          str_attr += ("%s, " % str(attributes[i]))
    else:
      if type(values[i]) is int:
        str_val += ("%i)" % values[i])
      elif type(values[i]) is float:
        str_val += ("%f)" % values[i])
      else:
        str_val += ("'%s')" % values[i])

      if type(attributes[i]) is str:
        str_attr += ("%s)" % attributes[i])
      else:
        str_attr += ("%s)" % str(attributes[i]))
  try:
    curs.execute("INSERT INTO %s %s VALUES %s" % (table, str_attr, str_val))
    conn.commit()
  except sqlite3.OperationalError:
    print("Ошибка при выполнении операции добавления")
  else:
    print("Операция успешно выполнена")


def UPDATE(table, attribute, value, attributes, values):
  str_attr = "("
  str_val = "("
  for i in range(len(attributes)):
    if i < len(attributes) - 1:
      if type(values[i]) is int:
        str_val += ("%i, " % values[i])
      elif type(values[i]) is float:
        str_val += ("%f, " % values[i])
      else:
        str_val += ("'%s', " % values[i])

      if type(attributes[i]) is str:
        str_attr += ("%s, " % attributes[i])
      else:
          str_attr += ("%s, " % str(attributes[i]))
    else:
      if type(values[i]) is int:
        str_val += ("%i)" % values[i])
      elif type(values[i]) is float:
        str_val += ("%f)" % values[i])
      else:
        str_val += ("'%s')" % values[i])

      if type(attributes[i]) is str:
        str_attr += ("%s)" % attributes[i])
      else:
        str_attr += ("%s)" % str(attributes[i]))
  try:
    if type(value) is int:
      curs.execute("UPDATE %s SET %s = %s WHERE %s = %i" %(table, str_attr, str_val, attribute, value))
    elif type(value) is float:
      curs.execute("UPDATE %s SET %s = %s WHERE %s = %f" %(table, str_attr, str_val, attribute, value))
    else:
      curs.execute("UPDATE %s SET %s = %s WHERE %s = %s" %(table, str_attr, str_val, attribute, value))
    conn.commit()
  except sqlite3.OperationalError:
    print("Ошибка при попытку обновить информацию о пользователе")
  else:
    print("Информация о пользователе успешно обновлена")

def DELETE(table, attribute, value):
    try:
      if type(value) is int:
        curs.execute(('DELETE FROM %s WHERE %s = %i' % (table, attribute)), (value,))
      elif type(value) is float:
        curs.execute(('DELETE FROM %s WHERE %s = %f' % (table, attribute)), (value,))
      else:
        curs.execute(('DELETE FROM %s WHERE %s = %s' % (table, attribute)), (value,))
      conn.commit()
    except sqlite3.OperationalError:
        print('Ошибка при выполнении операции удаления')
    else:
        print('Успешно удалено')

READ("user")
READ("user", "name", "User")
#READ("user", "id", 7)
#UPDATE("user", "id", 7, ("name", "height"), ("new user", 3.5))
#ADD("user", ("id", "name", "height"), (50, "new user", 3.5))
READ("user")
#DELETE("user", "id", 7)
READ("user")
conn.close()
# классы - виды запросов (select, update, insert)

# класс - структура/сущность со структурой, которую реализует какой-то конкретный объект
# например пользователь Elena или Irina

import os
import sqlite3

class User():

    def __init__(self, name, height):
        self.__name = name
        self.__height = height

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        print("setter")
        # реализовать проверку длины имени и если она меньше трех, выкинуть исключение ValueError в виде отдельной внутренней функции, которую вы вызываете здесь в конструкторе
        if len(self.name) < 3:
            raise ValueError("Имя должно состоять хотя бы из 3-х символов")
        self.__name = name

        if name == None:
            del self.name

    @name.deleter
    def name(self):
        print("deleter")

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, height):
        self.__check_height(height)
        self.__height = height

        if height == None:
            del self.height

    @height.deleter
    def height(self):
        print("deleter")

    def __check_height(self, height):
        pass

    def select(self, conn, sqlquery):
        sqlquery = "SELECT (?,?) FROM user WHERE (???)"
 

def singleton(cls):
    import functools

    instance = None
    
    @functools.wraps(cls)
    def inner(*args, **kwargs):
        nonlocal instance
        print(args, kwargs)
        if instance is None:
            instance = cls(*args, **kwargs) # == Connection(dbfile, dbtype='sqlite')
        return instance

    return inner


@singleton
class Connection():
    """
    Класс singleton для подключения к базе данных
    """
    def __init__(self, dbfile, dbtype="sqlite"):
        """
        dbfile - файл базы данных
        dbtype - тип базы данных
        """
        self.__filename = dbfile
        self.__conn = None
        self.__cursor = None
        if dbtype != "sqlite":
            raise NotImplementedError("Программа поддерживает только SQLite базы данных")
        if not os.path.exists(dbfile) or os.stat(dbfile).st_size == 0:
            raise FileNotFoundError("Базы данных не существует, либо она пуста")

    def connect(self):
        """
        Метод, предназначенный для подключения к базе данных и проверки наличия таблицы users
        """
        self.__conn = sqlite3.connect(self.__filename)
        self.__cursor = self.__conn.cursor()
        table_list = self.__conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='user'").fetchall()
        if len(table_list) == 0:
            raise Exception("Таблица не существует")
        else:
            return self.__conn

    def select(self, id):
        """
        id - ID пользователя
        """
        try: 
            data = self.__cursor.execute("SELECT * from user WHERE id = %i" % id)
        except sqlite3.OperationalError:
            print("Ошибка при работе с базой данных")
        else:
            user_data = data.fetchall()[0]
            return User(user_data[2], user_data[1])

    def insert(self, user_data):
        """
        Метод, предназначенный для добавления пользователя в таблицу
        """
        try:
            if type(user_data.height) is int:
              self.__cursor.execute("INSERT INTO user (height, name) VALUES (%i, '%s')" % (user_data.height, user_data.name))
            elif type(user_data.height) is float:
              self.__cursor.execute("INSERT INTO user (height, name) VALUES (%f, '%s')" % (user_data.height, user_data.name))
            else:
              print("Неверный тип данных")
            self.__conn.commit()
        except sqlite3.OperationalError:
            print("Ошибка при работе с базой данных")
        else:
            print("Пользователь добавлен")

    def update(self, id, user_data):
        """
        Метод, предназначенный для обновления информации о пользователе
        """
        try:
            if type(user_data.height) is int:
              self.__cursor.execute("UPDATE user SET name = '%s', height = %i WHERE id = %i" % (user_data.name, user_data.height, id))
            elif type(user_data.height) is float:
              self.__cursor.execute("UPDATE user SET name = '%s', height = %f WHERE id = %i" % (user_data.name, user_data.height, id))
            else:
              print("Неверный тип данных")
            self.__conn.commit()
        except sqlite3.OperationalError:
            print("Ошибка при работе с базой данных")
        else:
            print("Информация о пользователе обновлена")

    def delete(self, id):
        """
        Метод, предназначенный для удаления пользователя из таблицы
        """
        try:
            self.__cursor.execute("DELETE FROM user WHERE id = %i" % id)
            self.__conn.commit()
        except sqlite3.OperationalError:
            print("Ошибка при работе с базой данных")
        else:
            print("Пользователь удалён")

    @property
    def conn(self):
        return self.__conn

    @property
    def cursor(self):
        return self.__cursor


c = Connection("zhukov.db")
c.connect() 
c1 = Connection("zhukov123.db")

print(id(c1), id(c))

print(type(c))

#elena = User('Elena', 1.69)
#c.insert(elena)

#irina = User('Irina', 1.80)
#c.insert(irina)

c.select(5)
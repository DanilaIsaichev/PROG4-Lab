import main
import unittest

class TestBinTreeGeneration(unittest.TestCase):

    def test_rec(self):
        self.assertEqual(main.gen_bin_tree(2, 5), {'5': [{'8': []}, {'9': []}]})
        self.assertEqual(main.gen_bin_tree(3, 5), {'5': [{'8': [{'14': []}, {'12': []}]}, {'9': [{'16': []}, {'13': []}]}]})

    def test_rec_exceptions(self):
        self.assertRaises(ValueError, main.gen_bin_tree, -2, 3)
        self.assertRaisesRegex(ValueError, 'Height must be more or equal to 1', main.gen_bin_tree, -3, 5)

if __name__ == '__main__':
    unittest.main() 
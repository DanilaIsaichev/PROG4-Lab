import sqlite3

conn = sqlite3.connect("Chinook_Sqlite.sqlite")
cursor = conn.cursor()

#select
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT 3")
results = cursor.fetchall()
print(results)

#insert
cursor.execute("INSERT INTO Artist VALUES (NULL, 'Glenn Miller')")
conn.commit()

cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

#Выполнение нескольких запросов
cursor.executescript("""
INSERT INTO Artist VALUES (NULL, 'Bob Crosby');
INSERT INTO Artist VALUES (NULL, 'Kay Kyser');
INSERT INTO Artist VALUES (NULL, 'Bing Crosby');
""")

cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

#ordered
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT ?", ('3'))
results = cursor.fetchall()
print(results)

#named
cursor.execute("SELECT Name FROM Artist ORDER BY Name LIMIT :limit", {"limit": 3})
results = cursor.fetchall()
print(results)

#Добавление нескольких исполнителей
new_artists = [
    ("Glenn Miller",),
    ("Bob Crosby",),
    ("Kay Kyser",)
]
cursor.executemany("INSERT INTO Artist VALUES (NULL, ?)", new_artists)

cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
results = cursor.fetchall()
print(results)

#fetchone
cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3")
print(cursor.fetchone())

#iterator
for artist in cursor.execute("SELECT Name FROM Artist ORDER BY ArtistID DESC LIMIT 3"):
    print(artist)

conn.close()
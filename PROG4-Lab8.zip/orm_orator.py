from orator import DatabaseManager, Model

config = {
  "default": "sqlite",
  "sqlite": {
      "driver": "sqlite",
      "database": "Chinook_Sqlite.sqlite",
  },
}

db = DatabaseManager(config)

Model.set_connection_resolver(db)

class Artist(Model):
    __table__ = "Artist"
    __timestamps__ = False
    __primary_key__ = "ArtistId"
    __fillable__ = ["Name"]

#select
artist = Artist.find(1)
print("Artist:", artist.ArtistId, artist.Name)

#insert
''''
artist = Artist()
artist.name = "Dorris Day"
artist.save()
print("New artist:", artist.ArtistId, artist.name)
'''

Artist.create(Name = "Gene Kelly")
artist = Artist.find(300)
print("Artist:", artist.ArtistId, artist.Name)


#update
artist = Artist.find(299)
artist.Name = "Danny Kaye"
artist.save()
print("Artist:", artist.ArtistId, artist.Name)

#delete
artist = Artist.create(Name = "TEST ARTIST")
artist_id = artist.ArtistId
print("Artist:", artist.ArtistId, artist.Name)
Artist.destroy(artist.ArtistId)
'''
artist = Artist.find(artist_id)
print("Artist:", artist.ArtistId, artist.Name)
'''

print('-' * 15)
artists = Artist.where("ArtistId", ">=", 300).take(5).get()
for artist in artists:
    print(artist.ArtistId, artist.Name)
from peewee import *

conn = SqliteDatabase("Chinook_Sqlite.sqlite")

class BaseModel(Model):
    class Meta:
        database = conn

class Artist(BaseModel):
    artist_id = AutoField(column_name="ArtistId")
    name = TextField(column_name="Name", null=True)

    class Meta:
        table_name = "Artist"

def print_new_artists():
    print('-' * 15)
    cur_query = Artist.select().limit(5).order_by(Artist.artist_id.desc())
    for artist in cur_query.dicts().execute():
        print("Artist:", artist)

cursor = conn.cursor()

#Получение одного исполнителя
artist = Artist.get(Artist.artist_id == 200)
print("Artist:", artist.artist_id, artist.name)

#Получение нескольких исполнителей
query = Artist.select()
print(query)

query = Artist.select().where(Artist.artist_id >= 281).limit(5).order_by(Artist.artist_id.desc())
print(query)

artists_selected = query.dicts().execute()
print(artists_selected)
for artist in artists_selected:
    print("Artist:", artist)

#Создание нового исполнителя
Artist.create(name="Johnny Mercer")
print_new_artists()

artist = Artist(name="Debbie Reynolds")
artist.save()
print_new_artists()

artists_data = [{"name": "The Ink Spots"}, {"name": "The Chordettes"}]
Artist.insert_many(artists_data).execute()
print_new_artists()


#Изменение информации об исполнителе
artist = Artist(name="Johnny Horton")
artist.artist_id = 300
artist.save()
print_new_artists()


query = Artist.update(name=Artist.name + '!').where(Artist.artist_id >= 299)
query.execute()
print_new_artists()


#Удаление исполнителей
Artist.create(name="TEST ARTIST")
print_new_artists()
artist = Artist.get(Artist.artist_id == 300)
artist.delete_instance()
print_new_artists()

query = Artist.delete().where(Artist.artist_id > 300)
query.execute()
print_new_artists()

conn.close()